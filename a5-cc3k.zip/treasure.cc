#include <string>
#include "treasure.h"
#include "hero.h"

using namespace std;

Treasure::Treasure(int mod, string st):Item{mod,st}{}


