#include "werewolf.h"
using namespace std;

Werewolf::Werewolf() : Enemy{"Werewolf", 120, 30, 5} {}

