#include "troll.h"
using namespace std;

Troll::Troll() : Enemy{"Troll", 120, 25, 15} {}

