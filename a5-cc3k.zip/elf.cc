#include "elf.h"
using namespace std;

Elf::Elf() : Hero{"Elf", 140, 30, 10, 2} {}

