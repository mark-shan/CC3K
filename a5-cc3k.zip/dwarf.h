#ifndef _DWARF_H_
#define _DWARF_H_

#include "hero.h"

class Dwarf: public Hero {
	public:
	Dwarf();
};

#endif
