#include "vampire.h"
using namespace std;

Vampire::Vampire() : Enemy{"Vampire", 50, 25, 25} {}

