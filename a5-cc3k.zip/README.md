This is the description for the project.
