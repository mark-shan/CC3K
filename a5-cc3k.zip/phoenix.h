#ifndef _PHOENIX_H_
#define _PHOENIX_H_
#include "enemy.h"

class Phoenix: public Enemy {
	public:
	Phoenix();
};

#endif
