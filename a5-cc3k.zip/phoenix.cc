#include "phoenix.h"
using namespace std;

Phoenix::Phoenix() : Enemy{"Phoenix", 50, 35, 20} {}

