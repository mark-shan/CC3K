#include "human.h"
using namespace std;

Human::Human() : Hero{"Human", 140, 20, 20, 2} {}

