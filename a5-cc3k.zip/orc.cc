#include "orc.h"
using namespace std;

Orc::Orc() : Hero{"Orc", 180, 30, 25, 1} {}

