#ifndef _HUMAN_H_
#define _HUMAN_H_

#include "hero.h"

class Human: public Hero {
	public:
	Human();
};

#endif
