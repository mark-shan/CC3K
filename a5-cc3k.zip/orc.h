#ifndef _ORC_H_
#define _ORC_H_

#include "hero.h"

class Orc: public Hero {
	public:
	Orc();
};

#endif
