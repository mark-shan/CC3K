#ifndef _ELF_H_
#define _ELF_H_

#include "hero.h"

class Elf: public Hero {
	public:
	Elf();
};

#endif
