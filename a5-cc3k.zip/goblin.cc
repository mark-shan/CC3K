#include "goblin.h"
using namespace std;

Goblin::Goblin() : Enemy{"Goblin", 70, 5, 10} {}

